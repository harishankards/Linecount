<?php
header("location:../index.php?msg4=NotAllowed"); 
?>